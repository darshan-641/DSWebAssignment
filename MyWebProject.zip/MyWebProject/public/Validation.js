/**
 * 
 */
 
 function Register(){
	alert("entered register");
	const email = document.getElementById("uemail").value;
	const date = document.getElementById("udob").value;
	const password = document.getElementById("upass").value;
	const name = document.getElementById('uname').value;

	const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


	 alert("entered register");
	if( date == ""){
		alert("Please enter a date");
		return false;
	}

	if( name == ""){
		alert("username field cannot be invalid");
	}

	if( password == ""){
		alert("Password cannot be cempty");
	}

      if (emailRegex.test(email)) {

      } else {
        alert("Invalid email address!");
		return false;
      }

	  const passwordRegex = /^(?=.*[A-Z])(?=.*\W)(?=.{8,})/;

      if (passwordRegex.test(password)) {

      } else {
        alert("Invalid password! The password must be at least 8 characters long, contain at least one uppercase letter, and one symbol.");
		return false;
      }


	  const dob = new Date(date);


      const currentDate = new Date();
      const ageInMillis = currentDate - dob;
      const ageInYears = ageInMillis / (1000 * 60 * 60 * 24 * 365.25);
	  
      if (ageInYears >= 18) {
		
      }
	 else if( ageInYears <=0 ){
		alert("You cannot enter tommorows date");
	 } 
	  else {
        alert("Invalid date of birth! Age must be 18 years or above.");
		return false;
      }

	return true;
	

 }
 function checkEmptyField(fieldId) {
 
 	alert('checkEmptyField '+fieldId);
 	
 }
 
 function validate() {
				var x=document.getElementById('uname').value;
				var y=document.getElementById('upass').value;
				
				console.log('value of x '+x);
				console.log('value of y '+y);

				if(x =="") {
					//alert('Username cannot be blank');	
					document.getElementById("nameErr").innerHTML="Username cannot be blank";
					return false;
				}		
				
				if(y =="") {
					//alert('Password cannot be blank');	return false
					document.getElementById("passErr").innerHTML="Password cannot be blank";
					return false;
				}			
				return true;
			}	
 
 function clearTheForm() {
				document.getElementById('uname').value="";
				document.getElementById('upass').value="";
				
}

function clearNameErrMsg() {
				document.getElementById('nameErr').innerHTML="";

}
			
function clearPassErrMsg() {
				document.getElementById('passErr').innerHTML="";

}